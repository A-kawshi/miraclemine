   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2025 Student Registration System |Designed by : Kawshalya Amarasinghe.</a> 
                </div>

            </div>
        </div>
    </section>